import { mockLogs } from '../../src/data/mockData.js';

// In-memory storage for logs
let logs = [...mockLogs];

export const getAllLogs = (limit = 100, offset = 0, filters = {}) => {
  let filteredLogs = [...logs];
  
  // Apply filters
  if (filters.source) {
    filteredLogs = filteredLogs.filter(log => log.source === filters.source);
  }
  
  if (filters.level) {
    filteredLogs = filteredLogs.filter(log => log.level === filters.level);
  }
  
  if (filters.isAnomaly !== undefined) {
    filteredLogs = filteredLogs.filter(log => log.isAnomaly === filters.isAnomaly);
  }
  
  if (filters.startDate && filters.endDate) {
    filteredLogs = filteredLogs.filter(log => {
      const logDate = new Date(log.timestamp);
      return logDate >= new Date(filters.startDate) && logDate <= new Date(filters.endDate);
    });
  }
  
  // Sort by timestamp (newest first)
  filteredLogs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  
  // Paginate
  return {
    logs: filteredLogs.slice(offset, offset + limit),
    total: filteredLogs.length,
    page: Math.floor(offset / limit) + 1,
    totalPages: Math.ceil(filteredLogs.length / limit),
  };
};

export const getLogById = (id) => {
  return logs.find(log => log.id === id);
};

export const addLog = (logData) => {
  const newLog = {
    id: Math.random().toString(36).substring(2, 15),
    timestamp: new Date().toISOString(),
    ...logData,
  };
  
  // Simulate anomaly detection
  if (!newLog.anomalyScore) {
    newLog.anomalyScore = Math.random();
    newLog.isAnomaly = newLog.anomalyScore > 0.7;
  }
  
  logs.unshift(newLog);
  return newLog;
};

export const getLogSources = () => {
  return [...new Set(logs.map(log => log.source))];
};

export const getLogCategories = () => {
  return [...new Set(logs.map(log => log.category))];
};

export const getLogStatistics = () => {
  const total = logs.length;
  const anomalies = logs.filter(log => log.isAnomaly).length;
  
  return {
    total,
    anomalies,
    anomalyRate: (anomalies / total) * 100,
    byLevel: {
      info: logs.filter(log => log.level === 'info').length,
      warning: logs.filter(log => log.level === 'warning').length,
      error: logs.filter(log => log.level === 'error').length,
      critical: logs.filter(log => log.level === 'critical').length,
    },
    bySource: Object.fromEntries(
      [...new Set(logs.map(log => log.source))].map(source => [
        source,
        logs.filter(log => log.source === source).length,
      ])
    ),
  };
};

export default {
  getAllLogs,
  getLogById,
  addLog,
  getLogSources,
  getLogCategories,
  getLogStatistics,
};