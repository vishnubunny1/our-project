// Simulated user database
const users = [
  {
    id: '1',
    username: 'admin',
    password: '$2a$10$eCQDz.Yt.NkDfnImYYjJI.XCUQJz7eDFAAwYUeBVfKHzjxmXBpTGe', // "password"
    email: 'admin@example.com',
    role: 'admin',
    firstName: 'Admin',
    lastName: 'User',
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    username: 'analyst',
    password: '$2a$10$eCQDz.Yt.NkDfnImYYjJI.XCUQJz7eDFAAwYUeBVfKHzjxmXBpTGe', // "password"
    email: 'analyst@example.com',
    role: 'analyst',
    firstName: 'Security',
    lastName: 'Analyst',
    createdAt: new Date().toISOString(),
  },
];

export const findByUsername = (username) => {
  return users.find(user => user.username === username);
};

export const findById = (id) => {
  return users.find(user => user.id === id);
};

export const createUser = (userData) => {
  const newUser = {
    id: (users.length + 1).toString(),
    ...userData,
    createdAt: new Date().toISOString(),
  };
  
  users.push(newUser);
  return newUser;
};

export default {
  findByUsername,
  findById,
  createUser,
};