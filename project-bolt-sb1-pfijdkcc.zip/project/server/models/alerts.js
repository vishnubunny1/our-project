import { mockAlerts } from '../../src/data/mockData.js';
import { addLog } from './logs.js';

// In-memory storage for alerts
let alerts = [...mockAlerts];

export const getAllAlerts = (limit = 100, offset = 0, filters = {}) => {
  let filteredAlerts = [...alerts];
  
  // Apply filters
  if (filters.severity) {
    filteredAlerts = filteredAlerts.filter(alert => alert.severity === filters.severity);
  }
  
  if (filters.status) {
    filteredAlerts = filteredAlerts.filter(alert => alert.status === filters.status);
  }
  
  if (filters.source) {
    filteredAlerts = filteredAlerts.filter(alert => alert.source === filters.source);
  }
  
  if (filters.startDate && filters.endDate) {
    filteredAlerts = filteredAlerts.filter(alert => {
      const alertDate = new Date(alert.timestamp);
      return alertDate >= new Date(filters.startDate) && alertDate <= new Date(filters.endDate);
    });
  }
  
  // Sort by timestamp (newest first)
  filteredAlerts.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  
  // Paginate
  return {
    alerts: filteredAlerts.slice(offset, offset + limit),
    total: filteredAlerts.length,
    page: Math.floor(offset / limit) + 1,
    totalPages: Math.ceil(filteredAlerts.length / limit),
  };
};

export const getAlertById = (id) => {
  return alerts.find(alert => alert.id === id);
};

export const createAlert = (alertData) => {
  const newAlert = {
    id: Math.random().toString(36).substring(2, 15),
    timestamp: new Date().toISOString(),
    status: 'new',
    ...alertData,
  };
  
  alerts.unshift(newAlert);
  
  // Log the alert creation
  addLog({
    source: 'alert-system',
    level: alertData.severity === 'critical' || alertData.severity === 'high' ? 'critical' : 'warning',
    message: `Alert created: ${alertData.message}`,
    category: 'security',
    anomalyScore: 0.9,
    isAnomaly: true,
  });
  
  return newAlert;
};

export const updateAlertStatus = (id, status) => {
  const alertIndex = alerts.findIndex(alert => alert.id === id);
  
  if (alertIndex === -1) {
    return null;
  }
  
  alerts[alertIndex] = {
    ...alerts[alertIndex],
    status,
    updatedAt: new Date().toISOString(),
  };
  
  return alerts[alertIndex];
};

export const getAlertStatistics = () => {
  return {
    total: alerts.length,
    bySeverity: {
      critical: alerts.filter(alert => alert.severity === 'critical').length,
      high: alerts.filter(alert => alert.severity === 'high').length,
      medium: alerts.filter(alert => alert.severity === 'medium').length,
      low: alerts.filter(alert => alert.severity === 'low').length,
    },
    byStatus: {
      new: alerts.filter(alert => alert.status === 'new').length,
      acknowledged: alerts.filter(alert => alert.status === 'acknowledged').length,
      resolved: alerts.filter(alert => alert.status === 'resolved').length,
    },
  };
};

export default {
  getAllAlerts,
  getAlertById,
  createAlert,
  updateAlertStatus,
  getAlertStatistics,
};