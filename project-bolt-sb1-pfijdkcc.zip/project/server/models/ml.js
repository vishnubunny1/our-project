import { mockLogs } from '../../src/data/mockData.js';

// Simulated ML model performance metrics
const modelPerformance = {
  accuracy: 0.992,
  precision: 0.985,
  recall: 0.978,
  f1Score: 0.981,
  falsePositiveRate: 0.008,
  falseNegativeRate: 0.022,
  auc: 0.994,
  trainingTime: '2 hours 15 minutes',
  lastTrainingDate: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
  modelVersion: '1.2.3',
  improvementFromLastVersion: 0.012, // 1.2% improvement
};

// Simulated anomaly detection function
export const detectAnomalies = (logs) => {
  return logs.map(log => {
    // In a real system, this would use actual ML algorithms
    // Here we're just simulating with random scores
    const anomalyScore = Math.random();
    const isAnomaly = anomalyScore > 0.7;
    
    return {
      ...log,
      anomalyScore,
      isAnomaly,
      mlConfidence: isAnomaly ? 0.8 + (anomalyScore - 0.7) * 0.6 : 0.9 - anomalyScore * 0.3,
    };
  });
};

// Get anomaly insights
export const getAnomalyInsights = () => {
  const anomalyLogs = mockLogs.filter(log => log.isAnomaly);
  const anomalyCount = anomalyLogs.length;
  const anomalyPercentage = (anomalyCount / mockLogs.length) * 100;
  
  // Group anomalies by category
  const categoryCounts = {};
  anomalyLogs.forEach(log => {
    categoryCounts[log.category] = (categoryCounts[log.category] || 0) + 1;
  });
  
  // Sort categories by count
  const topCategories = Object.entries(categoryCounts)
    .sort((a, b) => b[1] - a[1])
    .map(([category, count]) => ({
      category,
      count,
      percentage: (count / anomalyCount) * 100,
    }));
  
  // Group anomalies by source
  const sourceCounts = {};
  anomalyLogs.forEach(log => {
    sourceCounts[log.source] = (sourceCounts[log.source] || 0) + 1;
  });
  
  // Sort sources by count
  const topSources = Object.entries(sourceCounts)
    .sort((a, b) => b[1] - a[1])
    .map(([source, count]) => ({
      source,
      count,
      percentage: (count / anomalyCount) * 100,
    }));
  
  // Time-based analysis
  const hourlyDistribution = Array(24).fill(0);
  anomalyLogs.forEach(log => {
    const hour = new Date(log.timestamp).getHours();
    hourlyDistribution[hour]++;
  });
  
  return {
    totalLogs: mockLogs.length,
    anomalyCount,
    anomalyPercentage,
    topCategories,
    topSources,
    hourlyDistribution,
    modelPerformance,
  };
};

// Get model performance
export const getModelPerformance = () => {
  return modelPerformance;
};

// Simulate model training
export const trainModel = async () => {
  // In a real system, this would trigger actual model training
  // Here we're just simulating the process
  
  return new Promise((resolve) => {
    setTimeout(() => {
      // Update model performance with slight improvements
      modelPerformance.accuracy += Math.random() * 0.01;
      modelPerformance.precision += Math.random() * 0.01;
      modelPerformance.recall += Math.random() * 0.01;
      modelPerformance.f1Score += Math.random() * 0.01;
      modelPerformance.falsePositiveRate -= Math.random() * 0.002;
      modelPerformance.falseNegativeRate -= Math.random() * 0.002;
      modelPerformance.auc += Math.random() * 0.005;
      
      // Ensure values stay within reasonable bounds
      modelPerformance.accuracy = Math.min(0.999, modelPerformance.accuracy);
      modelPerformance.precision = Math.min(0.999, modelPerformance.precision);
      modelPerformance.recall = Math.min(0.999, modelPerformance.recall);
      modelPerformance.f1Score = Math.min(0.999, modelPerformance.f1Score);
      modelPerformance.falsePositiveRate = Math.max(0.001, modelPerformance.falsePositiveRate);
      modelPerformance.falseNegativeRate = Math.max(0.001, modelPerformance.falseNegativeRate);
      modelPerformance.auc = Math.min(0.999, modelPerformance.auc);
      
      // Update training metadata
      modelPerformance.lastTrainingDate = new Date().toISOString();
      
      // Increment version
      const versionParts = modelPerformance.modelVersion.split('.');
      versionParts[2] = (parseInt(versionParts[2]) + 1).toString();
      modelPerformance.modelVersion = versionParts.join('.');
      
      // Calculate improvement
      modelPerformance.improvementFromLastVersion = Math.random() * 0.02;
      
      resolve({
        success: true,
        message: 'Model training completed successfully',
        performance: modelPerformance,
      });
    }, 3000); // Simulate 3 second training time
  });
};

export default {
  detectAnomalies,
  getAnomalyInsights,
  getModelPerformance,
  trainModel,
};