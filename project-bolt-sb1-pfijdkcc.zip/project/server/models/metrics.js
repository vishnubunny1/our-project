import { mockSystemMetrics } from '../../src/data/mockData.js';

// In-memory storage for system metrics
let metrics = [...mockSystemMetrics];

// Historical metrics for trends
const metricsHistory = [];

// Update metrics every minute
setInterval(() => {
  // Store current metrics in history
  metricsHistory.push({
    timestamp: new Date().toISOString(),
    metrics: JSON.parse(JSON.stringify(metrics)),
  });
  
  // Keep only last 24 hours of data
  const oneDayAgo = new Date();
  oneDayAgo.setHours(oneDayAgo.getHours() - 24);
  
  while (
    metricsHistory.length > 0 &&
    new Date(metricsHistory[0].timestamp) < oneDayAgo
  ) {
    metricsHistory.shift();
  }
  
  // Update current metrics with random variations
  metrics = metrics.map(metric => {
    let newValue = metric.value;
    
    // Random variation
    const variation = Math.random() * 10 - 5; // -5 to +5
    newValue += variation;
    
    // Ensure value stays within reasonable bounds
    if (metric.name.includes('Usage')) {
      newValue = Math.max(0, Math.min(100, newValue));
    } else if (metric.name === 'Network Traffic') {
      newValue = Math.max(0, Math.min(2000, newValue));
    } else if (metric.name === 'Log Ingestion Rate') {
      newValue = Math.max(0, Math.min(20000, newValue));
    } else if (metric.name === 'Alert Rate') {
      newValue = Math.max(0, Math.min(200, newValue));
    }
    
    // Determine trend
    let trend = 'stable';
    if (metricsHistory.length > 5) {
      const prevMetric = metricsHistory[metricsHistory.length - 5].metrics.find(
        m => m.id === metric.id
      );
      if (prevMetric) {
        if (newValue > prevMetric.value * 1.05) trend = 'up';
        else if (newValue < prevMetric.value * 0.95) trend = 'down';
      }
    }
    
    // Determine status
    let status = 'normal';
    if (metric.name === 'CPU Usage' || metric.name === 'Memory Usage' || metric.name === 'Disk Usage') {
      if (newValue > 90) status = 'critical';
      else if (newValue > 70) status = 'warning';
    }
    if (metric.name === 'Alert Rate') {
      if (newValue > 50) status = 'critical';
      else if (newValue > 20) status = 'warning';
    }
    
    return {
      ...metric,
      value: Math.round(newValue),
      status,
      trend,
    };
  });
}, 60000);

export const getAllMetrics = () => {
  return metrics;
};

export const getMetricById = (id) => {
  return metrics.find(metric => metric.id === id);
};

export const getMetricHistory = (id, hours = 24) => {
  const hoursAgo = new Date();
  hoursAgo.setHours(hoursAgo.getHours() - hours);
  
  return metricsHistory
    .filter(entry => new Date(entry.timestamp) >= hoursAgo)
    .map(entry => {
      const metricData = entry.metrics.find(m => m.id === id);
      return {
        timestamp: entry.timestamp,
        value: metricData ? metricData.value : null,
        status: metricData ? metricData.status : null,
      };
    });
};

export const updateMetric = (id, value) => {
  const metricIndex = metrics.findIndex(metric => metric.id === id);
  
  if (metricIndex === -1) {
    return null;
  }
  
  const oldValue = metrics[metricIndex].value;
  
  // Determine trend
  let trend = 'stable';
  if (value > oldValue * 1.05) trend = 'up';
  else if (value < oldValue * 0.95) trend = 'down';
  
  // Determine status
  let status = 'normal';
  const metricName = metrics[metricIndex].name;
  if (metricName === 'CPU Usage' || metricName === 'Memory Usage' || metricName === 'Disk Usage') {
    if (value > 90) status = 'critical';
    else if (value > 70) status = 'warning';
  }
  if (metricName === 'Alert Rate') {
    if (value > 50) status = 'critical';
    else if (value > 20) status = 'warning';
  }
  
  metrics[metricIndex] = {
    ...metrics[metricIndex],
    value,
    status,
    trend,
    updatedAt: new Date().toISOString(),
  };
  
  return metrics[metricIndex];
};

export default {
  getAllMetrics,
  getMetricById,
  getMetricHistory,
  updateMetric,
};