import express from 'express';
import Logs from '../models/logs.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { logger } from '../utils/logger.js';

const router = express.Router();

/**
 * @swagger
 * /api/logs:
 *   get:
 *     summary: Get all logs with pagination and filtering
 *     tags: [Logs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 100
 *         description: Maximum number of logs to return
 *       - in: query
 *         name: offset
 *         schema:
 *           type: integer
 *           default: 0
 *         description: Number of logs to skip
 *       - in: query
 *         name: source
 *         schema:
 *           type: string
 *         description: Filter by log source
 *       - in: query
 *         name: level
 *         schema:
 *           type: string
 *           enum: [info, warning, error, critical]
 *         description: Filter by log level
 *       - in: query
 *         name: isAnomaly
 *         schema:
 *           type: boolean
 *         description: Filter by anomaly status
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date-time
 *         description: Filter logs after this date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date-time
 *         description: Filter logs before this date
 *     responses:
 *       200:
 *         description: List of logs
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */
router.get('/', authenticate, async (req, res) => {
  try {
    const { 
      limit = 100, 
      offset = 0, 
      source, 
      level, 
      isAnomaly, 
      startDate, 
      endDate 
    } = req.query;
    
    const filters = {};
    
    if (source) filters.source = source;
    if (level) filters.level = level;
    if (isAnomaly !== undefined) filters.isAnomaly = isAnomaly === 'true';
    if (startDate) filters.startDate = startDate;
    if (endDate) filters.endDate = endDate;
    
    const result = Logs.getAllLogs(
      parseInt(limit), 
      parseInt(offset), 
      filters
    );
    
    res.json(result);
  } catch (error) {
    logger.error('Get logs error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/logs/{id}:
 *   get:
 *     summary: Get a log by ID
 *     tags: [Logs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Log ID
 *     responses:
 *       200:
 *         description: Log details
 *       404:
 *         description: Log not found
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */
router.get('/:id', authenticate, async (req, res) => {
  try {
    const log = Logs.getLogById(req.params.id);
    
    if (!log) {
      return res.status(404).json({ message: 'Log not found' });
    }
    
    res.json(log);
  } catch (error) {
    logger.error('Get log error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/logs:
 *   post:
 *     summary: Add a new log
 *     tags: [Logs]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - source
 *               - level
 *               - message
 *             properties:
 *               source:
 *                 type: string
 *               level:
 *                 type: string
 *                 enum: [info, warning, error, critical]
 *               message:
 *                 type: string
 *               category:
 *                 type: string
 *     responses:
 *       201:
 *         description: Log created successfully
 *       401:
 *         description: Not authenticated
 *       400:
 *         description: Invalid input
 *       500:
 *         description: Server error
 */
router.post('/', authenticate, async (req, res) => {
  try {
    const { source, level, message, category } = req.body;
    
    // Validate input
    if (!source || !level || !message) {
      return res.status(400).json({ message: 'Please provide source, level, and message' });
    }
    
    // Validate level
    if (!['info', 'warning', 'error', 'critical'].includes(level)) {
      return res.status(400).json({ message: 'Invalid log level' });
    }
    
    const newLog = Logs.addLog({
      source,
      level,
      message,
      category: category || 'uncategorized',
    });
    
    res.status(201).json(newLog);
  } catch (error) {
    logger.error('Add log error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/logs/statistics:
 *   get:
 *     summary: Get log statistics
 *     tags: [Logs]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Log statistics
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */
router.get('/statistics/summary', authenticate, async (req, res) => {
  try {
    const statistics = Logs.getLogStatistics();
    res.json(statistics);
  } catch (error) {
    logger.error('Get log statistics error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/logs/sources:
 *   get:
 *     summary: Get all log sources
 *     tags: [Logs]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of log sources
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */
router.get('/sources/list', authenticate, async (req, res) => {
  try {
    const sources = Logs.getLogSources();
    res.json(sources);
  } catch (error) {
    logger.error('Get log sources error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/logs/categories:
 *   get:
 *     summary: Get all log categories
 *     tags: [Logs]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of log categories
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */
router.get('/categories/list', authenticate, async (req, res) => {
  try {
    const categories = Logs.getLogCategories();
    res.json(categories);
  } catch (error) {
    logger.error('Get log categories error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;