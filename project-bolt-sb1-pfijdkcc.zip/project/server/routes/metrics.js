import express from 'express';
import Metrics from '../models/metrics.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { logger } from '../utils/logger.js';

const router = express.Router();

/**
 * @swagger
 * /api/metrics:
 *   get:
 *     summary: Get all system metrics
 *     tags: [Metrics]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of system metrics
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */
router.get('/', authenticate, async (req, res) => {
  try {
    const metrics = Metrics.getAllMetrics();
    res.json(metrics);
  } catch (error) {
    logger.error('Get metrics error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/metrics/{id}:
 *   get:
 *     summary: Get a metric by ID
 *     tags: [Metrics]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Metric ID
 *     responses:
 *       200:
 *         description: Metric details
 *       404:
 *         description: Metric not found
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */
router.get('/:id', authenticate, async (req, res) => {
  try {
    const metric = Metrics.getMetricById(req.params.id);
    
    if (!metric) {
      return res.status(404).json({ message: 'Metric not found' });
    }
    
    res.json(metric);
  } catch (error) {
    logger.error('Get metric error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/metrics/{id}/history:
 *   get:
 *     summary: Get historical data for a metric
 *     tags: [Metrics]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Metric ID
 *       - in: query
 *         name: hours
 *         schema:
 *           type: integer
 *           default: 24
 *         description: Number of hours of history to retrieve
 *     responses:
 *       200:
 *         description: Metric history
 *       404:
 *         description: Metric not found
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */
router.get('/:id/history', authenticate, async (req, res) => {
  try {
    const { hours = 24 } = req.query;
    
    const metric = Metrics.getMetricById(req.params.id);
    
    if (!metric) {
      return res.status(404).json({ message: 'Metric not found' });
    }
    
    const history = Metrics.getMetricHistory(req.params.id, parseInt(hours));
    
    res.json(history);
  } catch (error) {
    logger.error('Get metric history error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/metrics/{id}:
 *   patch:
 *     summary: Update a metric value
 *     tags: [Metrics]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Metric ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - value
 *             properties:
 *               value:
 *                 type: number
 *     responses:
 *       200:
 *         description: Metric updated successfully
 *       404:
 *         description: Metric not found
 *       401:
 *         description: Not authenticated
 *       400:
 *         description: Invalid input
 *       500:
 *         description: Server error
 */
router.patch('/:id', authenticate, authorize(['admin']), async (req, res) => {
  try {
    const { value } = req.body;
    
    if (value === undefined || isNaN(value)) {
      return res.status(400).json({ message: 'Please provide a valid numeric value' });
    }
    
    const updatedMetric = Metrics.updateMetric(req.params.id, parseFloat(value));
    
    if (!updatedMetric) {
      return res.status(404).json({ message: 'Metric not found' });
    }
    
    res.json(updatedMetric);
  } catch (error) {
    logger.error('Update metric error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;