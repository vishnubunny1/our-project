import express from 'express';
import ML from '../models/ml.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { logger } from '../utils/logger.js';

const router = express.Router();

/**
 * @swagger
 * /api/ml/insights:
 *   get:
 *     summary: Get ML-based anomaly insights
 *     tags: [Machine Learning]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: ML insights
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */
router.get('/insights', authenticate, async (req, res) => {
  try {
    const insights = ML.getAnomalyInsights();
    res.json(insights);
  } catch (error) {
    logger.error('Get ML insights error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/ml/performance:
 *   get:
 *     summary: Get ML model performance metrics
 *     tags: [Machine Learning]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: ML model performance
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */
router.get('/performance', authenticate, async (req, res) => {
  try {
    const performance = ML.getModelPerformance();
    res.json(performance);
  } catch (error) {
    logger.error('Get ML performance error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/ml/train:
 *   post:
 *     summary: Train the ML model
 *     tags: [Machine Learning]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Model training started
 *       401:
 *         description: Not authenticated
 *       403:
 *         description: Not authorized
 *       500:
 *         description: Server error
 */
router.post('/train', authenticate, authorize(['admin']), async (req, res) => {
  try {
    // Start training in the background
    ML.trainModel()
      .then(result => {
        logger.info('Model training completed:', result);
      })
      .catch(error => {
        logger.error('Model training error:', error);
      });
    
    // Return immediately
    res.json({
      message: 'Model training started',
      estimatedTime: '3 seconds',
    });
  } catch (error) {
    logger.error('Start ML training error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/ml/detect:
 *   post:
 *     summary: Detect anomalies in provided logs
 *     tags: [Machine Learning]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - logs
 *             properties:
 *               logs:
 *                 type: array
 *                 items:
 *                   type: object
 *     responses:
 *       200:
 *         description: Anomaly detection results
 *       401:
 *         description: Not authenticated
 *       400:
 *         description: Invalid input
 *       500:
 *         description: Server error
 */
router.post('/detect', authenticate, async (req, res) => {
  try {
    const { logs } = req.body;
    
    if (!logs || !Array.isArray(logs) || logs.length === 0) {
      return res.status(400).json({ message: 'Please provide an array of logs' });
    }
    
    const results = ML.detectAnomalies(logs);
    
    res.json({
      results,
      totalLogs: logs.length,
      anomalies: results.filter(log => log.isAnomaly).length,
    });
  } catch (error) {
    logger.error('Anomaly detection error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;