import express from 'express';
import Alerts from '../models/alerts.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { logger } from '../utils/logger.js';

const router = express.Router();

/**
 * @swagger
 * /api/alerts:
 *   get:
 *     summary: Get all alerts with pagination and filtering
 *     tags: [Alerts]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 100
 *         description: Maximum number of alerts to return
 *       - in: query
 *         name: offset
 *         schema:
 *           type: integer
 *           default: 0
 *         description: Number of alerts to skip
 *       - in: query
 *         name: severity
 *         schema:
 *           type: string
 *           enum: [low, medium, high, critical]
 *         description: Filter by alert severity
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [new, acknowledged, resolved]
 *         description: Filter by alert status
 *       - in: query
 *         name: source
 *         schema:
 *           type: string
 *         description: Filter by alert source
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date-time
 *         description: Filter alerts after this date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date-time
 *         description: Filter alerts before this date
 *     responses:
 *       200:
 *         description: List of alerts
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */
router.get('/', authenticate, async (req, res) => {
  try {
    const { 
      limit = 100, 
      offset = 0, 
      severity, 
      status, 
      source, 
      startDate, 
      endDate 
    } = req.query;
    
    const filters = {};
    
    if (severity) filters.severity = severity;
    if (status) filters.status = status;
    if (source) filters.source = source;
    if (startDate) filters.startDate = startDate;
    if (endDate) filters.endDate = endDate;
    
    const result = Alerts.getAllAlerts(
      parseInt(limit), 
      parseInt(offset), 
      filters
    );
    
    res.json(result);
  } catch (error) {
    logger.error('Get alerts error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/alerts/{id}:
 *   get:
 *     summary: Get an alert by ID
 *     tags: [Alerts]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Alert ID
 *     responses:
 *       200:
 *         description: Alert details
 *       404:
 *         description: Alert not found
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */
router.get('/:id', authenticate, async (req, res) => {
  try {
    const alert = Alerts.getAlertById(req.params.id);
    
    if (!alert) {
      return res.status(404).json({ message: 'Alert not found' });
    }
    
    res.json(alert);
  } catch (error) {
    logger.error('Get alert error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/alerts:
 *   post:
 *     summary: Create a new alert
 *     tags: [Alerts]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - severity
 *               - message
 *               - source
 *             properties:
 *               severity:
 *                 type: string
 *                 enum: [low, medium, high, critical]
 *               message:
 *                 type: string
 *               source:
 *                 type: string
 *               relatedLogs:
 *                 type: array
 *                 items:
 *                   type: string
 *     responses:
 *       201:
 *         description: Alert created successfully
 *       401:
 *         description: Not authenticated
 *       400:
 *         description: Invalid input
 *       500:
 *         description: Server error
 */
router.post('/', authenticate, async (req, res) => {
  try {
    const { severity, message, source, relatedLogs } = req.body;
    
    // Validate input
    if (!severity || !message || !source) {
      return res.status(400).json({ message: 'Please provide severity, message, and source' });
    }
    
    // Validate severity
    if (!['low', 'medium', 'high', 'critical'].includes(severity)) {
      return res.status(400).json({ message: 'Invalid alert severity' });
    }
    
    const newAlert = Alerts.createAlert({
      severity,
      message,
      source,
      relatedLogs: relatedLogs || [],
    });
    
    res.status(201).json(newAlert);
  } catch (error) {
    logger.error('Create alert error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/alerts/{id}/status:
 *   patch:
 *     summary: Update alert status
 *     tags: [Alerts]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Alert ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - status
 *             properties:
 *               status:
 *                 type: string
 *                 enum: [new, acknowledged, resolved]
 *     responses:
 *       200:
 *         description: Alert status updated successfully
 *       404:
 *         description: Alert not found
 *       401:
 *         description: Not authenticated
 *       400:
 *         description: Invalid input
 *       500:
 *         description: Server error
 */
router.patch('/:id/status', authenticate, async (req, res) => {
  try {
    const { status } = req.body;
    
    // Validate status
    if (!status || !['new', 'acknowledged', 'resolved'].includes(status)) {
      return res.status(400).json({ message: 'Invalid alert status' });
    }
    
    const updatedAlert = Alerts.updateAlertStatus(req.params.id, status);
    
    if (!updatedAlert) {
      return res.status(404).json({ message: 'Alert not found' });
    }
    
    res.json(updatedAlert);
  } catch (error) {
    logger.error('Update alert status error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @swagger
 * /api/alerts/statistics:
 *   get:
 *     summary: Get alert statistics
 *     tags: [Alerts]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Alert statistics
 *       401:
 *         description: Not authenticated
 *       500:
 *         description: Server error
 */
router.get('/statistics/summary', authenticate, async (req, res) => {
  try {
    const statistics = Alerts.getAlertStatistics();
    res.json(statistics);
  } catch (error) {
    logger.error('Get alert statistics error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;