# Cybersecurity Log Monitoring System

A comprehensive cybersecurity log monitoring system with real-time anomaly detection and threat visualization.

## Project Overview

This project consists of:

1. **Frontend**: React/TypeScript application with Tailwind CSS for the user interface
2. **Backend**: Node.js/Express API server with simulated ML capabilities

## Features

- Real-time log monitoring and visualization
- Anomaly detection with machine learning insights
- Alert management system
- System health monitoring
- User authentication and authorization
- Interactive dashboards and reports

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository
2. Install dependencies:

```bash
npm install
```

3. Create a `.env` file in the root directory with the following content:

```
PORT=3001
JWT_SECRET=your_jwt_secret_key_change_in_production
NODE_ENV=development
```

### Running the Application

To run both the frontend and backend concurrently:

```bash
npm run dev:full
```

Or run them separately:

- Frontend only: `npm run dev`
- Backend only: `npm run server`

## API Documentation

API documentation is available at `http://localhost:3001/api-docs` when the server is running.

## Authentication

The system includes a simulated authentication system with two default users:

1. **Admin User**
   - Username: `admin`
   - Password: `password`
   - Role: `admin`

2. **Analyst User**
   - Username: `analyst`
   - Password: `password`
   - Role: `analyst`

## Project Structure

```
├── server/                 # Backend server code
│   ├── index.js            # Server entry point
│   ├── middleware/         # Express middleware
│   ├── models/             # Data models
│   ├── routes/             # API routes
│   └── utils/              # Utility functions
├── src/                    # Frontend React application
│   ├── components/         # React components
│   ├── data/               # Mock data
│   ├── services/           # API services
│   └── types.ts            # TypeScript type definitions
├── .env                    # Environment variables
└── package.json            # Project dependencies
```

## Implementation Notes

### Backend Implementation

The backend is a simulated implementation that provides:

1. **Authentication**: JWT-based authentication with role-based access control
2. **Log Management**: API endpoints for retrieving, filtering, and analyzing logs
3. **Alert System**: Creation and management of security alerts
4. **Metrics**: System health monitoring and historical data
5. **ML Simulation**: Simulated machine learning capabilities for anomaly detection

### Frontend Implementation

The frontend provides:

1. **Dashboard**: Overview of security status with key metrics
2. **Log Viewer**: Detailed log viewing and filtering
3. **Alert Management**: Interface for handling security alerts
4. **ML Insights**: Visualization of anomaly detection results

## Production Considerations

For a production implementation, consider:

1. **Real ML Integration**: Replace the simulated ML with actual Python-based ML using scikit-learn/TensorFlow
2. **Database Integration**: Add a proper database (PostgreSQL, MongoDB) instead of in-memory storage
3. **Log Storage**: Implement Elasticsearch for efficient log storage and querying
4. **Visualization**: Add Kibana or Grafana for advanced data visualization
5. **Security Hardening**: Enhance security measures for production deployment
6. **Scalability**: Implement message queues and worker processes for handling high log volumes

## License

This project is licensed under the MIT License.