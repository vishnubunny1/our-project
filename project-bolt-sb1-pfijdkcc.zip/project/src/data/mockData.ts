import { LogEntry, Alert, SystemMetric } from '../types';

// Generate random timestamp within the last 24 hours
const randomTimestamp = () => {
  const now = new Date();
  const pastTime = new Date(now.getTime() - Math.random() * 24 * 60 * 60 * 1000);
  return pastTime.toISOString();
};

// Generate random ID
const randomId = () => Math.random().toString(36).substring(2, 15);

// Log sources
const logSources = [
  'firewall', 'auth.log', 'apache', 'nginx', 'mysql', 
  'postgresql', 'mongodb', 'redis', 'application', 'kernel'
];

// Log messages
const logMessages = [
  'User authentication failed',
  'Connection refused',
  'Permission denied',
  'Resource not found',
  'Service started',
  'Service stopped',
  'Configuration changed',
  'Memory usage exceeded threshold',
  'CPU usage exceeded threshold',
  'Disk usage exceeded threshold',
  'Network traffic spike detected',
  'Unusual login attempt',
  'Brute force attack detected',
  'SQL injection attempt',
  'XSS attempt detected',
  'File permission changed',
  'Suspicious file access',
  'Unusual process started',
  'System shutdown',
  'System startup'
];

// Log categories
const logCategories = [
  'authentication', 'authorization', 'network', 'system', 
  'database', 'application', 'security', 'performance'
];

// Generate mock logs
export const generateMockLogs = (count: number): LogEntry[] => {
  const logs: LogEntry[] = [];
  
  for (let i = 0; i < count; i++) {
    const anomalyScore = Math.random();
    const isAnomaly = anomalyScore > 0.7;
    
    let level: 'info' | 'warning' | 'error' | 'critical';
    if (anomalyScore < 0.5) level = 'info';
    else if (anomalyScore < 0.7) level = 'warning';
    else if (anomalyScore < 0.9) level = 'error';
    else level = 'critical';
    
    logs.push({
      id: randomId(),
      timestamp: randomTimestamp(),
      source: logSources[Math.floor(Math.random() * logSources.length)],
      level,
      message: logMessages[Math.floor(Math.random() * logMessages.length)],
      category: logCategories[Math.floor(Math.random() * logCategories.length)],
      anomalyScore,
      isAnomaly
    });
  }
  
  // Sort by timestamp (newest first)
  return logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
};

// Generate mock alerts
export const generateMockAlerts = (logs: LogEntry[]): Alert[] => {
  const anomalyLogs = logs.filter(log => log.isAnomaly);
  const alerts: Alert[] = [];
  
  for (let i = 0; i < anomalyLogs.length; i++) {
    if (Math.random() > 0.3) { // Not all anomalies become alerts
      const log = anomalyLogs[i];
      
      let severity: 'low' | 'medium' | 'high' | 'critical';
      if (log.anomalyScore < 0.75) severity = 'low';
      else if (log.anomalyScore < 0.85) severity = 'medium';
      else if (log.anomalyScore < 0.95) severity = 'high';
      else severity = 'critical';
      
      // Find related logs (same source or category)
      const relatedLogs = logs
        .filter(l => l.source === log.source || l.category === log.category)
        .slice(0, 5)
        .map(l => l.id);
      
      alerts.push({
        id: randomId(),
        timestamp: log.timestamp,
        severity,
        message: `Anomaly detected: ${log.message}`,
        source: log.source,
        status: Math.random() > 0.7 ? 'new' : (Math.random() > 0.5 ? 'acknowledged' : 'resolved'),
        relatedLogs
      });
    }
  }
  
  // Sort by timestamp (newest first)
  return alerts.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
};

// Generate system metrics
export const generateSystemMetrics = (): SystemMetric[] => {
  return [
    {
      id: '1',
      name: 'CPU Usage',
      value: Math.floor(Math.random() * 100),
      unit: '%',
      status: 'normal',
      trend: 'stable'
    },
    {
      id: '2',
      name: 'Memory Usage',
      value: Math.floor(Math.random() * 100),
      unit: '%',
      status: 'normal',
      trend: 'up'
    },
    {
      id: '3',
      name: 'Disk Usage',
      value: Math.floor(Math.random() * 100),
      unit: '%',
      status: 'normal',
      trend: 'up'
    },
    {
      id: '4',
      name: 'Network Traffic',
      value: Math.floor(Math.random() * 1000),
      unit: 'Mbps',
      status: 'normal',
      trend: 'stable'
    },
    {
      id: '5',
      name: 'Log Ingestion Rate',
      value: Math.floor(Math.random() * 10000),
      unit: 'logs/sec',
      status: 'normal',
      trend: 'stable'
    },
    {
      id: '6',
      name: 'Alert Rate',
      value: Math.floor(Math.random() * 100),
      unit: 'alerts/min',
      status: 'warning',
      trend: 'up'
    }
  ].map(metric => {
    // Determine status based on value
    let status: 'normal' | 'warning' | 'critical' = 'normal';
    if (metric.name === 'CPU Usage' || metric.name === 'Memory Usage' || metric.name === 'Disk Usage') {
      if (metric.value > 90) status = 'critical';
      else if (metric.value > 70) status = 'warning';
    }
    if (metric.name === 'Alert Rate') {
      if (metric.value > 50) status = 'critical';
      else if (metric.value > 20) status = 'warning';
    }
    
    return { ...metric, status };
  });
};

// Generate threat summary
export const generateThreatSummary = (alerts: Alert[]): ThreatSummary => {
  return {
    total: alerts.length,
    critical: alerts.filter(a => a.severity === 'critical').length,
    high: alerts.filter(a => a.severity === 'high').length,
    medium: alerts.filter(a => a.severity === 'medium').length,
    low: alerts.filter(a => a.severity === 'low').length
  };
};

// Initial data
export const mockLogs = generateMockLogs(100);
export const mockAlerts = generateMockAlerts(mockLogs);
export const mockSystemMetrics = generateSystemMetrics();
export const mockThreatSummary = generateThreatSummary(mockAlerts);