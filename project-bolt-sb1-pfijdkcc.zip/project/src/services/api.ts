import { Alert, LogEntry, SystemMetric, ThreatSummary } from '../types';

// Base API URL
const API_URL = 'http://localhost:3001/api';

// Get token from localStorage
const getToken = () => localStorage.getItem('token');

// Headers with authentication
const authHeaders = () => ({
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${getToken()}`,
});

// Authentication service
export const authService = {
  // Login user
  login: async (username: string, password: string) => {
    const response = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });
    
    if (!response.ok) {
      throw new Error('Authentication failed');
    }
    
    const data = await response.json();
    
    // Store token in localStorage
    localStorage.setItem('token', data.token);
    
    return data.user;
  },
  
  // Get current user
  getCurrentUser: async () => {
    const response = await fetch(`${API_URL}/auth/me`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to get user');
    }
    
    return response.json();
  },
  
  // Logout user
  logout: () => {
    localStorage.removeItem('token');
  },
  
  // Check if user is authenticated
  isAuthenticated: () => {
    return !!getToken();
  },
};

// Logs service
export const logsService = {
  // Get logs with pagination and filtering
  getLogs: async (params: {
    limit?: number;
    offset?: number;
    source?: string;
    level?: string;
    isAnomaly?: boolean;
    startDate?: string;
    endDate?: string;
  } = {}) => {
    const queryParams = new URLSearchParams();
    
    if (params.limit) queryParams.append('limit', params.limit.toString());
    if (params.offset) queryParams.append('offset', params.offset.toString());
    if (params.source) queryParams.append('source', params.source);
    if (params.level) queryParams.append('level', params.level);
    if (params.isAnomaly !== undefined) queryParams.append('isAnomaly', params.isAnomaly.toString());
    if (params.startDate) queryParams.append('startDate', params.startDate);
    if (params.endDate) queryParams.append('endDate', params.endDate);
    
    const response = await fetch(`${API_URL}/logs?${queryParams.toString()}`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch logs');
    }
    
    return response.json();
  },
  
  // Get log by ID
  getLogById: async (id: string) => {
    const response = await fetch(`${API_URL}/logs/${id}`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch log');
    }
    
    return response.json();
  },
  
  // Add new log
  addLog: async (logData: {
    source: string;
    level: 'info' | 'warning' | 'error' | 'critical';
    message: string;
    category?: string;
  }) => {
    const response = await fetch(`${API_URL}/logs`, {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify(logData),
    });
    
    if (!response.ok) {
      throw new Error('Failed to add log');
    }
    
    return response.json();
  },
  
  // Get log statistics
  getLogStatistics: async () => {
    const response = await fetch(`${API_URL}/logs/statistics/summary`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch log statistics');
    }
    
    return response.json();
  },
  
  // Get log sources
  getLogSources: async () => {
    const response = await fetch(`${API_URL}/logs/sources/list`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch log sources');
    }
    
    return response.json();
  },
  
  // Get log categories
  getLogCategories: async () => {
    const response = await fetch(`${API_URL}/logs/categories/list`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch log categories');
    }
    
    return response.json();
  },
};

// Alerts service
export const alertsService = {
  // Get alerts with pagination and filtering
  getAlerts: async (params: {
    limit?: number;
    offset?: number;
    severity?: string;
    status?: string;
    source?: string;
    startDate?: string;
    endDate?: string;
  } = {}) => {
    const queryParams = new URLSearchParams();
    
    if (params.limit) queryParams.append('limit', params.limit.toString());
    if (params.offset) queryParams.append('offset', params.offset.toString());
    if (params.severity) queryParams.append('severity', params.severity);
    if (params.status) queryParams.append('status', params.status);
    if (params.source) queryParams.append('source', params.source);
    if (params.startDate) queryParams.append('startDate', params.startDate);
    if (params.endDate) queryParams.append('endDate', params.endDate);
    
    const response = await fetch(`${API_URL}/alerts?${queryParams.toString()}`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch alerts');
    }
    
    return response.json();
  },
  
  // Get alert by ID
  getAlertById: async (id: string) => {
    const response = await fetch(`${API_URL}/alerts/${id}`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch alert');
    }
    
    return response.json();
  },
  
  // Create new alert
  createAlert: async (alertData: {
    severity: 'low' | 'medium' | 'high' | 'critical';
    message: string;
    source: string;
    relatedLogs?: string[];
  }) => {
    const response = await fetch(`${API_URL}/alerts`, {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify(alertData),
    });
    
    if (!response.ok) {
      throw new Error('Failed to create alert');
    }
    
    return response.json();
  },
  
  // Update alert status
  updateAlertStatus: async (id: string, status: 'new' | 'acknowledged' | 'resolved') => {
    const response = await fetch(`${API_URL}/alerts/${id}/status`, {
      method: 'PATCH',
      headers: authHeaders(),
      body: JSON.stringify({ status }),
    });
    
    if (!response.ok) {
      throw new Error('Failed to update alert status');
    }
    
    return response.json();
  },
  
  // Get alert statistics
  getAlertStatistics: async () => {
    const response = await fetch(`${API_URL}/alerts/statistics/summary`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch alert statistics');
    }
    
    return response.json();
  },
};

// Metrics service
export const metricsService = {
  // Get all metrics
  getAllMetrics: async () => {
    const response = await fetch(`${API_URL}/metrics`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch metrics');
    }
    
    return response.json();
  },
  
  // Get metric by ID
  getMetricById: async (id: string) => {
    const response = await fetch(`${API_URL}/metrics/${id}`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch metric');
    }
    
    return response.json();
  },
  
  // Get metric history
  getMetricHistory: async (id: string, hours = 24) => {
    const response = await fetch(`${API_URL}/metrics/${id}/history?hours=${hours}`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch metric history');
    }
    
    return response.json();
  },
  
  // Update metric value (admin only)
  updateMetric: async (id: string, value: number) => {
    const response = await fetch(`${API_URL}/metrics/${id}`, {
      method: 'PATCH',
      headers: authHeaders(),
      body: JSON.stringify({ value }),
    });
    
    if (!response.ok) {
      throw new Error('Failed to update metric');
    }
    
    return response.json();
  },
};

// ML service
export const mlService = {
  // Get ML insights
  getInsights: async () => {
    const response = await fetch(`${API_URL}/ml/insights`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch ML insights');
    }
    
    return response.json();
  },
  
  // Get ML model performance
  getModelPerformance: async () => {
    const response = await fetch(`${API_URL}/ml/performance`, {
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch ML performance');
    }
    
    return response.json();
  },
  
  // Train ML model (admin only)
  trainModel: async () => {
    const response = await fetch(`${API_URL}/ml/train`, {
      method: 'POST',
      headers: authHeaders(),
    });
    
    if (!response.ok) {
      throw new Error('Failed to start model training');
    }
    
    return response.json();
  },
  
  // Detect anomalies
  detectAnomalies: async (logs: LogEntry[]) => {
    const response = await fetch(`${API_URL}/ml/detect`, {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ logs }),
    });
    
    if (!response.ok) {
      throw new Error('Failed to detect anomalies');
    }
    
    return response.json();
  },
};