export interface LogEntry {
  id: string;
  timestamp: string;
  source: string;
  level: 'info' | 'warning' | 'error' | 'critical';
  message: string;
  category: string;
  anomalyScore: number;
  isAnomaly: boolean;
}

export interface Alert {
  id: string;
  timestamp: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  source: string;
  status: 'new' | 'acknowledged' | 'resolved';
  relatedLogs: string[];
}

export interface SystemMetric {
  id: string;
  name: string;
  value: number;
  unit: string;
  status: 'normal' | 'warning' | 'critical';
  trend: 'up' | 'down' | 'stable';
}

export interface ThreatSummary {
  total: number;
  critical: number;
  high: number;
  medium: number;
  low: number;
}