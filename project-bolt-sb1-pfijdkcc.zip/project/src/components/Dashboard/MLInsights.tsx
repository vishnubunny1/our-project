import React from 'react';
import { LogEntry } from '../../types';
import { Brain, AlertTriangle, TrendingUp } from 'lucide-react';

interface MLInsightsProps {
  logs: LogEntry[];
}

const MLInsights: React.FC<MLInsightsProps> = ({ logs }) => {
  // Calculate some insights from the logs
  const anomalyCount = logs.filter(log => log.isAnomaly).length;
  const anomalyPercentage = (anomalyCount / logs.length) * 100;
  
  // Group anomalies by category
  const categoryCounts: Record<string, number> = {};
  logs.filter(log => log.isAnomaly).forEach(log => {
    categoryCounts[log.category] = (categoryCounts[log.category] || 0) + 1;
  });
  
  // Sort categories by count
  const topCategories = Object.entries(categoryCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);
  
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h2 className="text-lg font-semibold mb-4 flex items-center">
        <Brain className="h-5 w-5 mr-2 text-purple-500" />
        ML Insights
      </h2>
      
      <div className="space-y-4">
        <div className="bg-purple-50 p-3 rounded-lg border border-purple-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Anomaly Rate</p>
              <p className="text-2xl font-bold text-purple-600">{anomalyPercentage.toFixed(1)}%</p>
            </div>
            <AlertTriangle className="h-8 w-8 text-purple-500" />
          </div>
          <p className="text-xs text-gray-500 mt-2">
            {anomalyPercentage > 5 
              ? 'Anomaly rate is higher than normal. Investigation recommended.'
              : 'Anomaly rate is within normal parameters.'}
          </p>
        </div>
        
        <div>
          <h3 className="text-sm font-medium mb-2">Top Anomaly Categories</h3>
          <div className="space-y-2">
            {topCategories.map(([category, count], index) => (
              <div key={category} className="flex items-center">
                <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
                  <div 
                    className="h-2.5 rounded-full bg-purple-500" 
                    style={{ width: `${(count / anomalyCount) * 100}%` }}
                  ></div>
                </div>
                <span className="text-xs whitespace-nowrap">
                  {category} ({count})
                </span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="border-t pt-3">
          <h3 className="text-sm font-medium mb-2">ML Model Performance</h3>
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-gray-50 p-2 rounded">
              <p className="text-xs text-gray-500">False Positive Rate</p>
              <p className="font-medium">0.8%</p>
            </div>
            <div className="bg-gray-50 p-2 rounded">
              <p className="text-xs text-gray-500">Detection Accuracy</p>
              <p className="font-medium">99.2%</p>
            </div>
          </div>
        </div>
        
        <div className="text-xs text-gray-500 flex items-center">
          <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
          Model accuracy improved by 1.2% in the last 24 hours
        </div>
      </div>
    </div>
  );
};

export default MLInsights;