import React from 'react';
import { LogEntry } from '../../types';

interface LogActivityProps {
  logs: LogEntry[];
}

const LogActivity: React.FC<LogActivityProps> = ({ logs }) => {
  const getLevelBadge = (level: string) => {
    switch (level) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'error':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'warning':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h2 className="text-lg font-semibold mb-4">Recent Log Activity</h2>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Time
              </th>
              <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Source
              </th>
              <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Level
              </th>
              <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Message
              </th>
              <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Anomaly
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {logs.slice(0, 5).map((log) => (
              <tr key={log.id} className={log.isAnomaly ? 'bg-red-50' : ''}>
                <td className="px-3 py-2 whitespace-nowrap text-xs text-gray-500">
                  {formatDate(log.timestamp)}
                </td>
                <td className="px-3 py-2 whitespace-nowrap text-xs">
                  {log.source}
                </td>
                <td className="px-3 py-2 whitespace-nowrap">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${getLevelBadge(log.level)}`}>
                    {log.level}
                  </span>
                </td>
                <td className="px-3 py-2 text-xs">
                  {log.message}
                </td>
                <td className="px-3 py-2 whitespace-nowrap text-xs">
                  {log.isAnomaly ? (
                    <span className="text-red-600 font-medium">Yes ({(log.anomalyScore * 100).toFixed(1)}%)</span>
                  ) : (
                    <span className="text-green-600">No</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="mt-4 text-center">
        <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
          View All Logs
        </button>
      </div>
    </div>
  );
};

export default LogActivity;