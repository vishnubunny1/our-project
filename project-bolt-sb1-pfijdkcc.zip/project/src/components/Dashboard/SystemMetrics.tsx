import React from 'react';
import { SystemMetric } from '../../types';
import { TrendingUp, TrendingDown, Minus, AlertCircle } from 'lucide-react';

interface SystemMetricsProps {
  metrics: SystemMetric[];
}

const SystemMetrics: React.FC<SystemMetricsProps> = ({ metrics }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'critical':
        return 'text-red-500';
      case 'warning':
        return 'text-yellow-500';
      default:
        return 'text-green-500';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-4 w-4" />;
      case 'down':
        return <TrendingDown className="h-4 w-4" />;
      default:
        return <Minus className="h-4 w-4" />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h2 className="text-lg font-semibold mb-4">System Health</h2>
      
      <div className="space-y-4">
        {metrics.map((metric) => (
          <div key={metric.id} className="border-b pb-3 last:border-0">
            <div className="flex justify-between items-center mb-1">
              <div className="flex items-center">
                <span className="font-medium">{metric.name}</span>
                {metric.status !== 'normal' && (
                  <AlertCircle className={`h-4 w-4 ml-2 ${getStatusColor(metric.status)}`} />
                )}
              </div>
              <div className={`flex items-center ${
                metric.trend === 'up' 
                  ? metric.name === 'Alert Rate' ? 'text-red-500' : 'text-green-500'
                  : metric.trend === 'down' 
                    ? metric.name === 'Alert Rate' ? 'text-green-500' : 'text-red-500'
                    : 'text-gray-500'
              }`}>
                {getTrendIcon(metric.trend)}
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
                <div 
                  className={`h-2.5 rounded-full ${
                    metric.status === 'critical' 
                      ? 'bg-red-500' 
                      : metric.status === 'warning' 
                        ? 'bg-yellow-500' 
                        : 'bg-green-500'
                  }`} 
                  style={{ width: `${metric.name.includes('Usage') ? metric.value : Math.min(100, metric.value / 10)}%` }}
                ></div>
              </div>
              <span className="text-sm font-medium whitespace-nowrap">
                {metric.value} {metric.unit}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SystemMetrics;