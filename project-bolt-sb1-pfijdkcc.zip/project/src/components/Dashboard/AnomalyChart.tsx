import React from 'react';
import { LogEntry } from '../../types';

interface AnomalyChartProps {
  logs: LogEntry[];
}

const AnomalyChart: React.FC<AnomalyChartProps> = ({ logs }) => {
  // Group logs by hour for the last 24 hours
  const hourlyData = React.useMemo(() => {
    const now = new Date();
    const data: { hour: string; total: number; anomalies: number }[] = [];
    
    // Create 24 hour buckets
    for (let i = 23; i >= 0; i--) {
      const hourDate = new Date(now);
      hourDate.setHours(now.getHours() - i);
      const hourStr = hourDate.getHours().toString().padStart(2, '0') + ':00';
      
      data.push({
        hour: hourStr,
        total: 0,
        anomalies: 0
      });
    }
    
    // Fill with log data
    logs.forEach(log => {
      const logDate = new Date(log.timestamp);
      const hoursDiff = Math.floor((now.getTime() - logDate.getTime()) / (1000 * 60 * 60));
      
      if (hoursDiff >= 0 && hoursDiff < 24) {
        const index = 23 - hoursDiff;
        data[index].total++;
        if (log.isAnomaly) {
          data[index].anomalies++;
        }
      }
    });
    
    return data;
  }, [logs]);

  // Calculate max value for scaling
  const maxValue = Math.max(...hourlyData.map(d => d.total));
  
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h2 className="text-lg font-semibold mb-4">Log Activity (24h)</h2>
      
      <div className="h-64">
        <div className="flex h-full">
          {/* Y-axis labels */}
          <div className="flex flex-col justify-between text-xs text-gray-500 pr-2">
            <div>100%</div>
            <div>75%</div>
            <div>50%</div>
            <div>25%</div>
            <div>0%</div>
          </div>
          
          {/* Chart */}
          <div className="flex-1 flex items-end">
            {hourlyData.map((data, index) => (
              <div 
                key={index} 
                className="flex-1 flex flex-col items-center justify-end h-full"
              >
                {/* Anomaly bar */}
                {data.anomalies > 0 && (
                  <div 
                    className="w-4/5 bg-red-500"
                    style={{ 
                      height: `${(data.anomalies / maxValue) * 100}%`,
                      minHeight: data.anomalies > 0 ? '2px' : '0'
                    }}
                  ></div>
                )}
                
                {/* Normal logs bar */}
                <div 
                  className="w-4/5 bg-blue-400"
                  style={{ 
                    height: `${((data.total - data.anomalies) / maxValue) * 100}%`,
                    minHeight: (data.total - data.anomalies) > 0 ? '2px' : '0'
                  }}
                ></div>
                
                {/* X-axis label */}
                <div className="text-xs text-gray-500 mt-1 transform -rotate-45 origin-top-left">
                  {data.hour}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="flex justify-center mt-6 space-x-4">
        <div className="flex items-center">
          <div className="w-3 h-3 bg-blue-400 mr-1"></div>
          <span className="text-xs text-gray-600">Normal Logs</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-red-500 mr-1"></div>
          <span className="text-xs text-gray-600">Anomalies</span>
        </div>
      </div>
    </div>
  );
};

export default AnomalyChart;