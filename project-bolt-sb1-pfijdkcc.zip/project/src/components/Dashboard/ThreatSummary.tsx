import React from 'react';
import { ThreatSummary as ThreatSummaryType } from '../../types';
import { AlertTriangle, AlertCircle, AlertOctagon } from 'lucide-react';

interface ThreatSummaryProps {
  summary: ThreatSummaryType;
}

const ThreatSummary: React.FC<ThreatSummaryProps> = ({ summary }) => {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h2 className="text-lg font-semibold mb-4 flex items-center">
        <AlertOctagon className="h-5 w-5 mr-2 text-red-500" />
        Threat Summary
      </h2>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-red-50 p-3 rounded-lg border border-red-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Critical Threats</p>
              <p className="text-2xl font-bold text-red-600">{summary.critical}</p>
            </div>
            <AlertOctagon className="h-8 w-8 text-red-500" />
          </div>
        </div>
        
        <div className="bg-orange-50 p-3 rounded-lg border border-orange-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">High Threats</p>
              <p className="text-2xl font-bold text-orange-600">{summary.high}</p>
            </div>
            <AlertCircle className="h-8 w-8 text-orange-500" />
          </div>
        </div>
        
        <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Medium Threats</p>
              <p className="text-2xl font-bold text-yellow-600">{summary.medium}</p>
            </div>
            <AlertTriangle className="h-8 w-8 text-yellow-500" />
          </div>
        </div>
        
        <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Low Threats</p>
              <p className="text-2xl font-bold text-blue-600">{summary.low}</p>
            </div>
            <AlertTriangle className="h-8 w-8 text-blue-500" />
          </div>
        </div>
      </div>
      
      <div className="mt-4 pt-3 border-t">
        <div className="flex justify-between items-center">
          <p className="text-sm text-gray-500">Total Alerts</p>
          <p className="text-xl font-bold">{summary.total}</p>
        </div>
      </div>
    </div>
  );
};

export default ThreatSummary;