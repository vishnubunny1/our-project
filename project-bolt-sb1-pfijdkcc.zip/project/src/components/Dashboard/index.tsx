import React from 'react';
import ThreatSummary from './ThreatSummary';
import SystemMetrics from './SystemMetrics';
import RecentAlerts from './RecentAlerts';
import LogActivity from './LogActivity';
import AnomalyChart from './AnomalyChart';
import MLInsights from './MLInsights';
import { 
  mockLogs, 
  mockAlerts, 
  mockSystemMetrics, 
  mockThreatSummary 
} from '../../data/mockData';

const Dashboard: React.FC = () => {
  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Security Dashboard</h1>
        <p className="text-gray-600">Real-time monitoring and threat detection</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <ThreatSummary summary={mockThreatSummary} />
            <SystemMetrics metrics={mockSystemMetrics} />
          </div>
          
          <div className="mb-6">
            <AnomalyChart logs={mockLogs} />
          </div>
          
          <div>
            <LogActivity logs={mockLogs} />
          </div>
        </div>
        
        <div>
          <div className="mb-6">
            <RecentAlerts alerts={mockAlerts} />
          </div>
          
          <div>
            <MLInsights logs={mockLogs} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;