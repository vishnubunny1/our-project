import React from 'react';
import { Shield, Bell, Settings, User } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gray-800 text-white p-4 flex justify-between items-center">
      <div className="flex items-center space-x-2">
        <Shield className="h-8 w-8 text-blue-400" />
        <h1 className="text-xl font-bold">CyberSentry</h1>
      </div>
      <div className="flex items-center space-x-4">
        <div className="relative">
          <Bell className="h-6 w-6 cursor-pointer hover:text-blue-400" />
          <span className="absolute -top-1 -right-1 bg-red-500 text-xs rounded-full h-4 w-4 flex items-center justify-center">
            5
          </span>
        </div>
        <Settings className="h-6 w-6 cursor-pointer hover:text-blue-400" />
        <div className="flex items-center space-x-2 cursor-pointer">
          <div className="bg-blue-500 rounded-full h-8 w-8 flex items-center justify-center">
            <User className="h-5 w-5" />
          </div>
          <span>Admin</span>
        </div>
      </div>
    </header>
  );
};

export default Header;