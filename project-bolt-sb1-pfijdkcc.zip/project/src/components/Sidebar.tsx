import React from 'react';
import { 
  LayoutDashboard, 
  AlertTriangle, 
  FileText, 
  BarChart2, 
  Settings, 
  Shield, 
  Users, 
  Database,
  HelpCircle
} from 'lucide-react';

interface SidebarItemProps {
  icon: React.ReactNode;
  text: string;
  active?: boolean;
  badge?: number;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, text, active = false, badge }) => {
  return (
    <li className={`flex items-center space-x-2 p-3 rounded-lg cursor-pointer ${
      active ? 'bg-blue-700 text-white' : 'text-gray-300 hover:bg-gray-700'
    }`}>
      {icon}
      <span>{text}</span>
      {badge && (
        <span className="ml-auto bg-red-500 text-white text-xs rounded-full px-2 py-1">
          {badge}
        </span>
      )}
    </li>
  );
};

const Sidebar: React.FC = () => {
  return (
    <div className="bg-gray-800 text-white w-64 flex flex-col h-full">
      <div className="p-4">
        <h2 className="text-xl font-semibold mb-6">Navigation</h2>
        <ul className="space-y-2">
          <SidebarItem 
            icon={<LayoutDashboard className="h-5 w-5" />} 
            text="Dashboard" 
            active={true} 
          />
          <SidebarItem 
            icon={<AlertTriangle className="h-5 w-5" />} 
            text="Alerts" 
            badge={5} 
          />
          <SidebarItem 
            icon={<FileText className="h-5 w-5" />} 
            text="Logs" 
          />
          <SidebarItem 
            icon={<BarChart2 className="h-5 w-5" />} 
            text="Analytics" 
          />
          <SidebarItem 
            icon={<Shield className="h-5 w-5" />} 
            text="Threats" 
          />
          <SidebarItem 
            icon={<Database className="h-5 w-5" />} 
            text="Data Sources" 
          />
          <SidebarItem 
            icon={<Users className="h-5 w-5" />} 
            text="Users" 
          />
          <SidebarItem 
            icon={<Settings className="h-5 w-5" />} 
            text="Settings" 
          />
        </ul>
      </div>
      <div className="mt-auto p-4 border-t border-gray-700">
        <SidebarItem 
          icon={<HelpCircle className="h-5 w-5" />} 
          text="Help & Support" 
        />
      </div>
    </div>
  );
};

export default Sidebar;